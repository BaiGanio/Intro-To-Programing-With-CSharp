﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.MiserPiggy
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "Fiffer Pig","Practical Pig", "Fiddler Pig" };

            foreach (var name in names.OrderByDescending(x => x))
            {
                Console.WriteLine($"{name} -> {CalculateSyum(name)}");
            }
        }

        private static int CalculateSyum(string names)
        {
            int sum = 0;
            for (int i = 0; i < names.Length; i++)
            {
                sum += (int)names[i];
            }

            return sum;
        }
    }
}
