﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.PiggyGamblers
{
    class PiggyGamblers
    {
        static void Main(string[] args)
        {
            try
            {
                string[] cards = Console.ReadLine().ToUpper().Split().ToArray();

                switch (cards[0])
                {
                    case "A":
                        Console.Write("Ace");
                        break;
                    case "Q":
                        Console.Write("Queen");
                        break;
                    case "K":
                        Console.Write("King");
                        break;
                    case "J":
                        Console.Write("Jack");
                        break;
                    case "7":
                        Console.Write("Seven");
                        break;
                    case "8":
                        Console.Write("Eight");
                        break;
                    case "9":
                        Console.Write("Nine");
                        break;
                    case "10":
                        Console.Write("Ten");
                        break;
                    default :
                        Console.WriteLine("Тази карта не същесвува в тестето.");
                        break;


                }
                switch (cards[1])
                {
                    case "D":
                        Console.WriteLine(" Of Diamonds");
                        break;
                    case "S":
                        Console.WriteLine(" Of Spades");
                        break;
                    case "H":
                        Console.WriteLine(" Of Hearts");
                        break;
                    case "C":
                        Console.WriteLine(" Of Clubs");
                        break;
                }
            }
            
              catch (Exception)
            {

                Console.WriteLine("Невалидни данни.");
            }
    }
}
}
