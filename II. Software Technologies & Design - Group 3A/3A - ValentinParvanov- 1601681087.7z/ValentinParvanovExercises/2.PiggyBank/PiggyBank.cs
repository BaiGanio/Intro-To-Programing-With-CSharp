﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.PiggyBank
{
    class PiggyBank
    {
        static void Main(string[] args)
        {
            try
            {
                double bonus = 0;

                for (int i = 0; i < 30; i++)
                {
                    int randomNumber = int.Parse(Console.ReadLine());
                    double sqrtNumber = Math.Sqrt(randomNumber);

                    if (sqrtNumber >= 1 && sqrtNumber <= 300)
                    {
                        bonus += sqrtNumber * 5.1;
                    }
                    else if (sqrtNumber >= 301 && sqrtNumber <= 600)
                    {
                        bonus += sqrtNumber * 10.098;
                    }
                    else if (sqrtNumber >= 609 && sqrtNumber <= 999)
                    {
                        bonus += sqrtNumber * 10.00001;
                    }
                }
                Console.WriteLine($"Piggies will save {bonus:f4} for a 31-day. ");
                if(bonus * 12 > 1000000)
                {
                    Console.WriteLine($"Piggies will save more than a million in a year.");
                }
                else
                {
                    Console.WriteLine($"Piggies will save less than a million in a year.");
                }

            }
            catch (Exception)
            {

                Console.WriteLine("Невалиден вход.");
            }
        }
    }
}
